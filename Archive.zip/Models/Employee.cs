namespace netAPI.Models;

public class Employee
{
    public int Id { get; set; }
    public string? Employee_Name { get; set; }
    public int Employee_Salary {get;set;}
    public int Employee_Age { get; set; }
    public string? Profile_Image { get; set; }
}